import { Component } from '@angular/core';
import { StudentDataService } from './Services/student-data.service';
import {FormGroup, FormControl} from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})


/*export class ProfileEditorComponent {
  profileForm = new FormGroup({
    firstName: new FormControl(''),
    lastName: new FormControl(''),
  });   */
export class AppComponent {
  title = 'StudentApp';
  students:any;

  onSubmit() {
    // TODO: Use EventEmitter with form value
    //console.warn(this.profileForm.value);
    console.log("Onsubmit");
  }
  constructor(private studentData:StudentDataService){
    this.studentData.getStudent().subscribe((data)=>{
      console.log(data);
      this.students = data;
    })
  }
}
